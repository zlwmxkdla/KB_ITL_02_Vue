const d1 = new Date();

let name = '홍길동';
let r1 = `${name} 님에게 ${d1.toDateString()} + 에 연락했다.`;
console.log(r1);
