import { add } from '../02-19.js';

console.log(add(4));
